<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
   	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
      	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
body {margin: 0;}

ul.sidenav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 25%;
    background-color: #f1f1f1;
    position: fixed;
    height: 100%;
    overflow: auto;
}

ul.sidenav li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
}

ul.sidenav li a.active {
    background-color: #4CAF50;
    color: white;
}

ul.sidenav li a:hover:not(.active) {
    background-color: #555;
    color: white;
}

div.content {
    margin-left: 25%;
    padding: 1px 16px;
    height: 1000px;
}

@media screen and (max-width: 2560px){
    ul.sidenav {
        width:100%;
        height:auto;
        position:relative;
    }
    ul.sidenav li a {
        float: left;
        padding: 15px;
    }
    div.content {margin-left:0;}
}

@media screen and (max-width: 400px){
    ul.sidenav li a {
        text-align: center;
        float: none;
    }
}
</style>
</head>
    <body>

        <ul class="sidenav">
          <li><a class="inactive" href="ecCoorHome.php">Student EC Claims</a></li>
          <li><a href="coorECstatus.php">Faculty EC Status</a></li>
          <li><a class="active" href="ThreeLogin.html">LOGOUT</a></li>
        </ul>

        <div class="content">
          <h2>Update Student EC-Claim</h2>
          <form id="stuECupload" name="studentUpload" action=" " method="post">
            <table border="1" align="center">
            <td align="center">
            <?php
            $link = mysqli_connect("localhost", "root", "", "enterprise");

            $faculty = mysqli_real_escape_string($link, $_SESSION['SESS_COOR_FAC']);

            $sql1 = "SELECT * FROM faculty WHERE Fac_Name = '$faculty' AND EC_Status = 'Pending'";

            $result = mysqli_query($link, $sql1);

              echo"<tr align='center'>";
              echo"<th>ID</th>";
              echo"<th>Student Name</th>";
              echo"<th>Subject</th>";
              echo"<th>Upload</th>";
              echo"<th>Comment</th>";
              echo"<th>Date</th>";
              echo"<th colspan='2'>Approvel</th>";
              echo"</tr>";

            while($test = mysqli_fetch_array($result))
            {
              $id = $test['Fac_ID'];

              echo"<tr align='center'>";
              echo"<td><font color='black'>" .$test['Fac_ID']."</font></td>";
              echo"<td><font color='black'>" .$test['Stu_Uname']."</font></td>";
              echo"<td><font color='black'>" .$test['Stu_Subject']."</font></td>";
              echo"<td><img width='200' height='200' src='data:image;base64,".base64_encode( $test['EC_Upload'] )."'/></td>";
              echo"<td><font color='black'>". $test['Comment']. "</font></td>";
              echo"<td><font color='black'>". $test['EC_Upl_Date']. "</font></td>";
              echo"<td><a style='color:black' class='btn btn-default' href ='approve.php?Fac_ID=$id'>Approve</a></td>";
      				echo"<td><a style='color:black' class='btn btn-default' href ='reject.php?Fac_ID=$id'>Reject</a></td>";
              echo"</tr>";
            }
            mysqli_close($link);
            ?>
          </td>
          </table>
          </form>
          </div>
    </body>
</html>

<!--//This interface i referred from this http://www.w3schools.com/css/tryit.asp?filename=trycss_navbar_vertical_responsive-->
