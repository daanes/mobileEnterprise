<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  	<title>Student EC-Status</title>
  	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
   	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
      	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

		<style>
    body {margin: 0;}

    ul.sidenav {
        list-style-type: none;
        margin: 0;
        padding: 0;
        width: 25%;
        background-color: #f1f1f1;
        position: fixed;
        height: 100%;
        overflow: auto;
    }

    ul.sidenav li a {
        display: block;
        color: #000;
        padding: 8px 16px;
        text-decoration: none;
    }

    ul.sidenav li a.active {
        background-color: #4CAF50;
        color: white;
    }

    ul.sidenav li a:hover:not(.active) {
        background-color: #555;
        color: white;
    }

    div.content {
        margin-left: 25%;
        padding: 1px 16px;
        height: 1000px;
    }

    @media screen and (max-width: 2560px){
        ul.sidenav {
            width:100%;
            height:auto;
            position:relative;
        }
        ul.sidenav li a {
            float: left;
            padding: 15px;
        }
        div.content {margin-left:0;}
    }

    @media screen and (max-width: 400px){
        ul.sidenav li a {
            text-align: center;
            float: none;
        }
    }

    </style>
   </head>
   <body>

        <ul class="sidenav">
          <li><a href="Student Information Page.html">Student EC-Upload</a></li>
          <li><a href="studentStatus.html">Student EC-Status</a></li>
          <li><a class="active" href="ThreeLogin.html">LOGOUT</a></li>
        </ul>

        <div class="page-header" style="text-align:center">
          <h2><strong>Student Extenuation Circumtances Claim Status</strong></h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <form id="stuECupload" name="studentUpload" action=" " method="post">
                      <table border="1" align="center">
                      <td align="center">
                      <?php
                			$link = mysqli_connect("localhost", "root", "", "enterprise");

                      $stuuname = mysqli_real_escape_string($link, $_SESSION['SESS_STU_UNAME']);

                			$sql1 = "SELECT * FROM faculty WHERE Stu_Uname = '$stuuname' ";

                			$result = mysqli_query($link, $sql1);

                				echo"<tr align='center'>";
                				echo"<th>ID</th>";
                				echo"<th>Subject</th>";
                				echo"<th>Upload</th>";
                				echo"<th>Comment</th>";
                				echo"<th>Date</th>";
                				echo"<th>EC Status</th>";
                				echo"</tr>";

                			while($test = mysqli_fetch_array($result))
                			{

                				echo"<tr align='center'>";
                				echo"<td><font color='black'>" .$test['Fac_ID']."</font></td>";
                        echo"<td><font color='black'>" .$test['Stu_Subject']."</font></td>";
                				echo"<td><img width='200' height='200' src='data:image;base64,".base64_encode( $test['EC_Upload'] )."'/></td>";
                				echo"<td><font color='black'>". $test['Comment']. "</font></td>";
                				echo"<td><font color='black'>". $test['EC_Upl_Date']. "</font></td>";
                				echo"<td><font color='black'>". $test['EC_Status']. "</font></td>";
                				echo"</tr>";
                			}
                			mysqli_close($link);
                			?>
                    </td>
                    </table>
                    </form>
                 </div>
            </div>
          </div>

	</body>
		</br>
		</br>
</html>
