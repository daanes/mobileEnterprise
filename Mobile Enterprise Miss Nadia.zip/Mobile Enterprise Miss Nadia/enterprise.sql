-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2017 at 10:38 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enterprise`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Adm_ID` int(100) NOT NULL,
  `Adm_Uname` varchar(100) NOT NULL,
  `Adm_Psw` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Adm_ID`, `Adm_Uname`, `Adm_Psw`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `ec_coordinator`
--

CREATE TABLE `ec_coordinator` (
  `Coor_ID` int(100) NOT NULL,
  `Coor_Name` varchar(100) NOT NULL,
  `Coor_Email` varchar(100) NOT NULL,
  `Coor_Faculty` varchar(100) NOT NULL,
  `Coor_Uname` varchar(100) NOT NULL,
  `Coor_Psw` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ec_coordinator`
--

INSERT INTO `ec_coordinator` (`Coor_ID`, `Coor_Name`, `Coor_Email`, `Coor_Faculty`, `Coor_Uname`, `Coor_Psw`) VALUES
(1, 'Jeya', 'khoghukill@gmail.com', 'Business and Accounting', 'jeya', 'jeya'),
(2, 'khoghu', 'khoghukill@gmail.com', '', 'khoghu', 'khoghu'),
(3, 'kill', 'khoghukill@gmail.com', '', 'k', 'k'),
(4, 'fdsfsdf', 'khoghukill@gmail.com', 'Creative Arts and Design', 'jhgjgj', 'jhjgjghj'),
(5, 'kumar', 'pk458800@gmail.com', 'Business and Accounting', 'kumar08', '12345'),
(6, 'kumar', 'pk458800@gmail.com', 'Business and Accounting', 'kumar', '12345'),
(8, 'd', 'khoghuk@gmail.com', 'Hostipatily and Tourism', 'd', 'd'),
(9, 't', 'khoghuk@gmail.com', 'Business and Accounting', 't', 't');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `Fac_ID` int(100) NOT NULL,
  `Fac_Name` varchar(100) NOT NULL,
  `Stu_Subject` varchar(100) NOT NULL,
  `EC_Upload` blob NOT NULL,
  `EC_Upl_Date` date NOT NULL,
  `Comment` varchar(100) NOT NULL,
  `EC_Status` varchar(100) NOT NULL,
  `Stu_Uname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `Man_ID` int(100) NOT NULL,
  `Man_Uname` varchar(100) NOT NULL,
  `Man_Psw` varchar(100) NOT NULL,
  `Man_Name` varchar(100) NOT NULL,
  `Man_Num` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`Man_ID`, `Man_Uname`, `Man_Psw`, `Man_Name`, `Man_Num`) VALUES
(1, 'dash', 'dash', 'darshini', '0191181191');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Stu_ID` int(100) NOT NULL,
  `Stu_Name` varchar(100) NOT NULL,
  `Stu_Email` varchar(100) NOT NULL,
  `Stu_Faculty` varchar(100) NOT NULL,
  `Stu_Uname` varchar(100) NOT NULL,
  `Stu_Psw` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Stu_ID`, `Stu_Name`, `Stu_Email`, `Stu_Faculty`, `Stu_Uname`, `Stu_Psw`) VALUES
(1, 'danny', 'khoghu_kill@hotmail.com', 'Creative Arts and Design', 'danny', 'danny'),
(2, 'khoghu', 'pk458800@gmail.com', 'Business and Accounting', 'khoghu', 'khoghu'),
(3, 'csaac', 'khoghu_kill@hotmail.com', 'Business and Accounting', 't', 't'),
(4, 'f', 'khoghukill@gmail.com', 'Hostipatily and Tourism', 'f', 'f');

-- --------------------------------------------------------

--
-- Table structure for table `upload_date`
--

CREATE TABLE `upload_date` (
  `Upload_ID` int(11) NOT NULL,
  `Upload_Due_Date` date NOT NULL,
  `Upload_Closure_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_date`
--

INSERT INTO `upload_date` (`Upload_ID`, `Upload_Due_Date`, `Upload_Closure_Date`) VALUES
(1, '2017-03-21', '2017-03-08'),
(2, '2017-03-16', '2017-03-29'),
(3, '2017-03-01', '2017-03-14');