<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<?php
$link = mysqli_connect('localhost', 'root', '', 'enterprise');

// Check connection
if($link === false)
{
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Escape user inputs for security
$username = mysqli_real_escape_string($link, $_POST['corRegUname']);
$email = mysqli_real_escape_string($link, $_POST['corRegEmail']);



$userdupli = "SELECT * FROM ec_coordinator WHERE Coor_Uname='$username'";

$result = $link->query($userdupli);

if ($row = $result->fetch_assoc()) {
	//echo ("You username or password incorrect!");
	echo "<script>alert('The username exist in database!')</script>";
	echo "<script>setTimeout(\"location.href = 'register.html';\",500);</script>";

}
else
{
function send_mail($email,$message,$subject)
{
require 'phpmailer/PHPMailerAutoload.php'; /*  <----This thing need PHPMailer.. Remember dont delete PHPMailer !*/

		$mail = new PHPMailer;

		//$mail->SMTPDebug = 3;                               // Enable verbose debug output
		$mail->isSMTP();                                      // Set mailer to use SMTP
		$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
		$mail->SMTPAuth = true;                               // Enable SMTP authentication
		$mail->Username = 'khoghukill@gmail.com';                 // SMTP username
		$mail->Password = 'scsjcit1106008';                           // SMTP password
		$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
		$mail->Port = 587;                                    // TCP port to connect to

		$mail->setFrom('fkhoghukill@gmail.com', 'Mailer');
		$mail->addAddress('khoghukill@gmail.com', 'Admin');     // Add a recipient
		$mail->addAddress($email);               // Name is optional
		$mail->addReplyTo('khoghukill@gmail.com', 'Information');

		$mail->isHTML(true);                                  // Set email format to HTML
		$mail->Subject = $subject;
		$mail->MsgHTML($message);
		$mail->SMTPOptions = array('ssl' => array('verify_peer' => false,'verify_peer_name' => false,'allow_self_signed' => true));

		if(!$mail->send())
		{
			echo "<script>alert('Email can not send, register againl!')</script>";
			echo "<script>setTimeout(\"location.href = 'register.html';\",500);</script>";

		}
		else
		{
			echo "<script>alert('Email has been send to coordinator Email!')</script>";
			echo "<script>setTimeout(\"location.href = 'register.html';\",500);</script>";

		}

 }

 $email = trim($_POST['corRegEmail']); /* <--this email will received a mail from sender*/
 $user = ($_POST['corRegUname']);
 $upsw = ($_POST['corRegPsw']);

   $message = "
      Hi, $user this is the site for you to process on the Students EC <br>
	  The administrator department send the username and the password <br>
	  to login to the side the below given the username and the password.
      <br /><br />
	  http://localhost/test/Mobile%20Enterprise%20Miss%20Nadia/ThreeLogin.html
	  <br /><br />
      This is your username and password for the sites<br/><br>
	  <br />
	  Username: $user
	  <br />
	  Password: $upsw
	  <br />
	  <br />
      Please login<br/>";

   $subject = "Email Username and Password for Student";

$password = mysqli_real_escape_string($link, $_POST['corRegPsw']);
$name = mysqli_real_escape_string($link, $_POST['corRegName']);
$faculty = mysqli_real_escape_string($link, $_POST['corRegFac']);


// attempt in phpsert query execution
$sql = "INSERT INTO ec_coordinator (Coor_Name, Coor_Email, Coor_Faculty, Coor_Uname, Coor_Psw) VALUES ('$name', '$email', '$faculty', '$username' , '$password')";

if(mysqli_query($link, $sql))
{
    echo " ";
	 send_mail($email,$message,$subject);
}
else
{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}

// close connection
mysqli_close($link);
?>
<body>
</body>
</html>
<body>
</body>
</html>
