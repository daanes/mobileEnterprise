<?php
$link = mysqli_connect("localhost", "root", "", "enterprise"); //Database Connection With PhpMyAdmin

//Start session
session_start();

if(isset($_POST) && count($_POST)>0) {
	$rdbtn = $_POST['ecRadio'];


      if($rdbtn == "ecCoordinator") {

	$username1 = $_POST['corLogUname'];
	$password1 = $_POST['corLogPsw'];

	// Checking the values are existing in the database or not
	$query1 = "SELECT * FROM `ec_coordinator` WHERE Coor_Uname='$username1' and Coor_Psw='$password1'";
	$result1 = mysqli_query($link, $query1) or die(mysqli_error($link));
	$count1 = mysqli_num_rows($result1);

	// If the posted values are equal to the database values, then session will be created for the user.
	if ($count1)
	{
		//Login Successful
    session_regenerate_id();
    $coor = mysqli_fetch_assoc($result1);
    $_SESSION['SESS_COOR_ID'] = $coor['Coor_ID'];
    $_SESSION['SESS_COOR_FAC'] = $coor['Coor_Faculty'];
		$_SESSION['SESS_COOR_UNAME'] = $coor['Coor_Uname'];

    session_write_close();
		header("location:ecCoorHome.php");
	}
	else
	{
		echo "<script>alert('You username or password incorrect!')</script>";
		echo "<script>setTimeout(\"location.href = 'ThreeLogin.html';\",500);</script>";
	}
	}
	if ($rdbtn == "ecManager") {
  {
		$username2 = $_POST['corLogUname'];
		$password2 = $_POST['corLogPsw'];

		// Checking the values are existing in the database or not
		$query2 = "SELECT * FROM `manager` WHERE Man_Uname='$username2' and Man_Psw='$password2'";
		$result2 = mysqli_query($link, $query2) or die(mysqli_error($link));
		$count2 = mysqli_num_rows($result2);

		// If the posted values are equal to the database values, then session will be created for the user.
		if ($count2)
		{
		header("location:ecManHome.html");
		}
		else
		{
		 echo "<script>alert('You username or password incorrect!')</script>";
		 echo "<script>setTimeout(\"location.href = 'ThreeLogin.html';\",500);</script>";
		}
		}
  }

  }
?>
