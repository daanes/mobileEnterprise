<?php
$link = mysqli_connect("localhost", "root", "", "enterprise"); //Database Connection With PhpMyAdmin

//Start session
session_start();

if (isset($_POST['stuLogUname']) and isset($_POST['stuLogPsw']))
{
	$username = $_POST['stuLogUname'];
	$password = $_POST['stuLogPsw'];

	// Checking the values are existing in the database or not
	$query = "SELECT * FROM `student` WHERE Stu_Uname='$username' and Stu_Psw='$password'";  //
	$result = mysqli_query($link, $query) or die(mysqli_error($link));
	$count = mysqli_num_rows($result);

	// If the posted values are equal to the database values, then session will be created for the user.
	if ($count)
	{
    //Login Successful
    session_regenerate_id();
    $student = mysqli_fetch_assoc($result);
    $_SESSION['SESS_STUDENT_ID'] = $student['Stu_ID'];
    $_SESSION['SESS_STU_FAC'] = $student['Stu_Faculty'];
		$_SESSION['SESS_STU_UNAME'] = $student['Stu_Uname'];

    session_write_close();
		header("location:StudentUploadPage.php");
	}
	else
	{
		echo "<script>alert('You username or password incorrect!')</script>";
		echo "<script>setTimeout(\"location.href = 'ThreeLogin.html';\",500);</script>";
	}
}
?>

<?php
$link = mysqli_connect("localhost", "root", "", "enterprise"); //Database Connection With PhpMyAdmin

if (isset($_POST['admLogUname']) and isset($_POST['admLogPsw']))
  {
	$username3 = $_POST['admLogUname'];
	$password3 = $_POST['admLogPsw'];

	// Checking the values are existing in the database or not
	$query3 = "SELECT * FROM `admin` WHERE Adm_Uname='$username3' and Adm_Psw='$password3'";
	$result3 = mysqli_query($link, $query3) or die(mysqli_error($link));
	$count3 = mysqli_num_rows($result3);

	// If the posted values are equal to the database values, then session will be created for the user.
	if ($count3)
	{
		header("location:adminHome.html");
	}
	else
	{
		echo "<script>alert('You username or password incorrect!')</script>";
		echo "<script>setTimeout(\"location.href = 'ThreeLogin.html';\",500);</script>";
	}
  }
?>
