<?php
	session_start();
?>
<?php

$link = mysqli_connect("localhost", "root", "", "enterprise");


function send_mail($email,$message,$subject)
{

require 'phpmailer/PHPMailerAutoload.php';   //<----This thing need PHPMailer.. Remember dont delete PHPMailer !


    $mail = new PHPMailer;

    //$mail->SMTPDebug = 3;                               // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'khoghukill@gmail.com';                 // SMTP username
    $mail->Password = 'scsjcit1106008';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    $mail->setFrom('fkhoghukill@gmail.com', 'Mailer');
    $mail->addAddress('khoghukill@gmail.com', 'Admin');     // Add a recipient
    $mail->addAddress($email);               // Name is optional
    $mail->addReplyTo('khoghukill@gmail.com', 'Information');

    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->MsgHTML($message);
    $mail->SMTPOptions = array('ssl' => array('verify_peer' => false,'verify_peer_name' => false,'allow_self_signed' => true));

    if(!$mail->send())
    {
      echo "<script>alert('Email can not send, click again!')</script>";
      echo "<script>setTimeout(\"location.href = 'ecCoorHome.php';\",500);</script>";

    }
    else
    {
      echo "<script>alert('Email has been send to student Email!')</script>";
      echo "<script>setTimeout(\"location.href = 'ecCoorHome.php';\",500);</script>";

    }

 }

 $id = $_REQUEST['Fac_ID'];

 $sql = "SELECT * FROM faculty WHERE Fac_ID  = '$id'";

 $result = mysqli_query($link, $sql);

 $test = mysqli_fetch_array($result);
// $test = mysqli_fetch_array($result);

$stuuname = trim($test['Stu_Uname']);

$sql2 = "SELECT * FROM student WHERE Stu_Uname = '$stuuname'";

$result2 = mysqli_query($link, $sql2);

$test2 = mysqli_fetch_array($result2);
// $test = mysqli_fetch_array($result);

$email = trim($test2['Stu_Email']);

$message = "
 Hai, $stuuname your ec claims have been Reject <br>
 More enquire about the EC can contact with the college
 <br /><br />
 <br /> ";

 $subject = "EC Claim process by EC Coordinator";

 $cooruname = mysqli_real_escape_string($link, $_SESSION['SESS_COOR_UNAME']);

 $query = "UPDATE faculty SET EC_Status ='Reject', Coor_Uname = '$cooruname' WHERE Fac_ID = '$id' ";


 if(mysqli_query($link, $query))
 {
     echo " ";
     send_mail($email,$message,$subject);
 }
 else
 {
     echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
 }


?>
