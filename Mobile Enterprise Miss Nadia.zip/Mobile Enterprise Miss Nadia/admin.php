<?php

$username=$_POST['username'];
$password=$_POST['password'];


$sql = "SELECT * FROM studentlogin WHERE username='$username' AND password='$password' ";
$result = $conn->query($sql);

if (!$row = $result->fetch_assoc()) {
	echo ("You username or password incorrect!");
	
}
else {
	
	header('location:admin.html');

}


?>