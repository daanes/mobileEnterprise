	<?php
		session_start();
	?>
	<?php
	
	 $link = mysqli_connect("localhost", "root", "", "enterprise");
	 $sql1 = "SELECT * FROM upload_date ORDER BY Upload_ID DESC";
	 $result = mysqli_query($link, $sql1);
	 $test = mysqli_fetch_array($result);
	
	 if (!$result)
	 {
		die("Error: Data not found..");
	 }
	
	$Name = $test['Upload_Closure_Date'];
	 ?>
	
	<!DOCTYPE html>
	<html lang="en">
	  <head>
		<title>Student Information Page</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<style>
		  body {margin: 0;}
	
		  ul.sidenav
		  {
			list-style-type: none;
			margin: 0;
			padding: 0;
			width: 25%;
			background-color: #f1f1f1;
			position: fixed;
			height: 100%;
			overflow: auto;
		 }
	
		 ul.sidenav li a
		 {
			display: block;
			color: #000;
			padding: 8px 16px;
			text-decoration: none;
		  }
	
		 ul.sidenav li a.active
		 {
			background-color: #4CAF50;
			color: white;
		 }
	
		 ul.sidenav li a:hover:not(.active)
		 {
			background-color: #555;
			color: white;
		 }
	
		 div.content
		 {
			margin-left: 25%;
			padding: 1px 16px;
			height: 1000px;
		 }
	
		 @media screen and (max-width: 2560px)
		 {
			ul.sidenav
			{
				width:100%;
				height:auto;
				position:relative;
			}
			ul.sidenav li a
			{
				float: left;
				padding: 15px;
			}
			div.content {margin-left:0;}
		 }
	
		 @media screen and (max-width: 400px)
		 {
			ul.sidenav li a
			{
				text-align: center;
				float: none;
			}
		 }
	
	  </style>
	</head>
	<body onload="myFunction()">
		<ul class="sidenav">
		  <li><a href="../Mobile Enterprise Miss Nadia/StudentUploadPage.php">Student EC-Upload</a></li>
		  <li><a href="../Mobile Enterprise Miss Nadia/coorECstatus.php">Student EC-Status</a></li>
		  <li><a class="active" href="../Mobile Enterprise Miss Nadia/ThreeLogin.html">LOGOUT</a></li>
		</ul>
	
		<div class="page-header" style="text-align:center">
		  <h2><strong>Extenuation Circumtances Claims</strong></h2>
		</div>
	
		<div class="container">
		  <div class="row">
			<div class="col-sm-4">
				 <form method="post"  enctype="multipart/form-data">
					<p>Select Faculty :</p>
				  <div class="input-group">
					<span class="input-group-addon"><i class="glyphicon glyphicon-list-alt"></i></span>
					<select style="width: 200px;" type="select" class="form-control" name="subject" required>
					  <option>  </option>
					  <option value="Enterpise Web Software Development">   Enterpise Web Software Development </option>
					  <option value="Interaction Design">   Interaction Design  </option>
					  <option value="Information Analysis">   Information Analysis  </option>
					</select>
				  </div>
				  </br>
	
				  <div class="input-group">
					<span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
					<input style="width: 200px;" id="UploadDueDate" type="date" class="form-control" name="UploadDueDate" value="<?php echo $Name ?>" readonly>
				  </div>
				  </br>
	
				  <div class="input-group">
					<span class="input-group-addon"><i class="glyphicon glyphicon-upload"></i></span>
			 <input style="width: 200px;" id="UploadFile" type="file" class="form-control" name="uploadFile" placeholder="UploadFile" required>
			 </div>
			  </br>
	
			 <div class="input-group">
			 <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
			 <input style="width: 200px;" id="UploadDate" type="text" class="form-control" name="uploadDate" placeholder="UploadDate" readonly>
			 </div>
		   </br>
	
	
			 <div class="input-group">
			 <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
			   <textarea rows="4" cols="50" name="comment" placeholder="Reason of EC-Claim" required> </textarea>
			 </div>
			   </br>
	
				<button type="submit" name="claim" class="btn btn-default">Submit</button>
	<?php
			if(isset($_POST['claim']))
				   {
									 $link = mysqli_connect('localhost', 'root', '', 'enterprise');
	
									function send_mail($email,$message,$subject)
									{
	
									require '../Mobile Enterprise Miss Nadia/phpmailer/PHPMailerAutoload.php';   //<----This thing need PHPMailer.. Remember dont delete PHPMailer !
	
	
										  $mail = new PHPMailer;
	
											//$mail->SMTPDebug = 3;                               // Enable verbose debug output
											$mail->isSMTP();                                      // Set mailer to use SMTP
											$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
											$mail->SMTPAuth = true;                               // Enable SMTP authentication
											$mail->Username = 'khoghukill@gmail.com';                 // SMTP username
											$mail->Password = 'scsjcit1106008';                           // SMTP password
											$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
											$mail->Port = 587;                                    // TCP port to connect to
	
											$mail->setFrom('fkhoghukill@gmail.com', 'Mailer');
											$mail->addAddress('khoghukill@gmail.com', 'Admin');     // Add a recipient
											$mail->addAddress($email);               // Name is optional
											$mail->addReplyTo('khoghukill@gmail.com', 'Information');
											$mail->addCC($email); 
	
											$mail->isHTML(true);                                  // Set email format to HTML
											$mail->Subject = $subject;
											$mail->MsgHTML($message);
											$mail->SMTPOptions = array('ssl' => array('verify_peer' => false,'verify_peer_name' => false,'allow_self_signed' => true));
	
											if(!$mail->send())
											{
												echo "<script>alert('Email can not send, register againl!')</script>";
												echo "<script>setTimeout(\"location.href = 'StudentUploadPage.php';\",500);</script>";
	
											}
											else
											{
												echo "<script>alert('Email has been send to coordinator Email!')</script>";
												echo "<script>setTimeout(\"location.href = 'StudentUploadPage.php';\",500);</script>";
	
											}
	
									 }
	
									$stufaculty = mysqli_real_escape_string($link, $_SESSION['SESS_STU_FAC']);
									$stuuname = mysqli_real_escape_string($link, $_SESSION['SESS_STU_UNAME']);
	
									$query = "SELECT * FROM ec_coordinator WHERE Coor_Faculty = '$stufaculty'";
	
									$result = mysqli_query($link, $query);
									// $test = mysqli_fetch_array($result);
	
									while($test = mysqli_fetch_array($result))
								 {
									 $email = trim($test['Coor_Email']);
								 }
	
	
									$message = "
									 $stuuname, This student have send EC Claim for <br>
									 Late Submission of assighments  <br>
									 Below have a link to process on the student EC Claim.
									 <br /><br />
									 http://localhost/test/Mobile%20Enterprise%20Miss%20Nadia/ThreeLogin.html
									 <br /> ";
	
									 $subject = "EC Claim by Students";
	
					 $image = mysqli_real_escape_string($link, $_FILES['uploadFile']['name']);
					 $uploadfile = $_FILES['uploadFile']['tmp_name'];
					// $uploadName = $_FILES['uploadFile']['tmp_name'];
					$image_name =$_FILES['uploadFile']['name'];
					 
					 
					 $uplfile = file_get_contents($uploadfile);
					 $stusubject = mysqli_real_escape_string($link, $_POST['subject']);
					 $comment = mysqli_real_escape_string($link, $_POST['comment']);
	
					move_uploaded_file($uploadfile,"uploads/$image_name");
	
	
					 // attempt in phpsert query execution
					 $sql = "INSERT INTO `faculty`(EC_Upload, image, Fac_Name,Stu_Subject,EC_Upl_Date,Comment, EC_Status, Stu_Uname)
					 VALUES (?,'$image', '$stufaculty','$stusubject', CURDATE(), '$comment', 'Pending', '$stuuname')";
	
	
					 $stmt = mysqli_prepare($link,$sql);
	
					 mysqli_stmt_bind_param($stmt, "s" , $uplfile);
					 mysqli_stmt_execute($stmt);
	
					 $check = mysqli_stmt_affected_rows($stmt);
	
					 if($check==1)
					   {
						  $msg = 'Successful Send';
					 }
					   else
					   {
						 $msg = 'Could not upload';
					   }
	
									 if(mysqli_query($link, $query))
									 {
										 echo " ";
										   send_mail($email,$message,$subject);
									 }
									 else
									 {
										 echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
									 }
	
						}
	?>
	</form>
		   </div>
		   </div>
		   </div>
		   <script>
		   function myFunction() {
			 var currentDate = new Date(),
			 day = currentDate.getDate(),
			 month = currentDate.getMonth() + 1,
			 year = currentDate.getFullYear();
			 document.getElementById('UploadDate').value = ("0" + month + "/" + day + "/" + year);
		   }
		   </script>
	</body>
	</html>
