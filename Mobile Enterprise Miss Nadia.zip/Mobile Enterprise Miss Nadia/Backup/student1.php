<?php
$link = mysqli_connect("localhost", "root", "", "enterprise");

if (isset($_POST['stuLogUname']) and isset($_POST['stuLogPsw']))
  {
	$username = $_POST['stuLogUname'];
	$password = $_POST['stuLogPsw'];

	// Checking the values are existing in the database or not
	$query = "SELECT * FROM `student` WHERE Stu_Name='$username' and Stu_Psw='$password'";
	$result = mysqli_query($link, $query) or die(mysqli_error($link));
	$count = mysqli_num_rows($result);

	// If the posted values are equal to the database values, then session will be created for the user.
	if ($count)
	{
		header("location:StudentInformationPage.html");
	}
	else
	{
		echo "<script>alert('You username or password incorrect!')</script>";
		echo "<script>setTimeout(\"location.href = 'ThreeLogin.html';\",500);</script>";
	}
  }

if(isset($_POST) && count($_POST)!=0) {
  
if (isset($_POST['corLogUname']) and isset($_POST['corLogPsw']) and isset($_POST['ecRadio']))
  {
	$username1 = $_POST['corLogUname'];
	$password1 = $_POST['corLogPsw'];

	// Checking the values are existing in the database or not
	$query1 = "SELECT * FROM `ec_coordinator` WHERE Coor_Uname='$username1' and Coor_Psw='$password1'";
	$result1 = mysqli_query($link, $query1) or die(mysqli_error($link1));
	$count1 = mysqli_num_rows($result1);

	// If the posted values are equal to the database values, then session will be created for the user.
	if ($count1)
	{
		header("location:admin.html");
	}
	else
	{
		echo "<script>alert('You username or password incorrect!')</script>";
		echo "<script>setTimeout(\"location.href = 'ThreeLogin.html';\",500);</script>";
	}
  }		
  elseif (isset($_POST['corLogUname']) and isset($_POST['corLogPsw']) and isset($_POST['ecRadio']))
  {
		$username2 = $_POST['corLogUname'];
		$password2 = $_POST['corLogPsw'];

		// Checking the values are existing in the database or not
		$query2 = "SELECT * FROM `manager` WHERE Man_Uname='$username2' and Man_Psw='$password2'";
		$result2 = mysqli_query($link, $query2) or die(mysqli_error($link2));
		$count2 = mysqli_num_rows($result2);

		// If the posted values are equal to the database values, then session will be created for the user.
		if ($count2)
		{
		header("location:admin.html");
		}
		else
		{
		echo "<script>alert('You username or password incorrect!')</script>";
		echo "<script>setTimeout(\"location.href = 'ThreeLogin.html';\",500);</script>";
		}
  }
	
}

if (isset($_POST['admLogUname']) and isset($_POST['admLogPsw']))
  {
	$username3 = $_POST['admLogUname'];
	$password3 = $_POST['admLogPsw'];

	// Checking the values are existing in the database or not
	$query3 = "SELECT * FROM `admin` WHERE Adm_Uname='$username3' and Adm_Psw='$password3'";
	$result3 = mysqli_query($link, $query3) or die(mysqli_error($link));
	$count3 = mysqli_num_rows($result3);

	// If the posted values are equal to the database values, then session will be created for the user.
	if ($count3)
	{
		header("location:admin.html");
	}
	else
	{
		echo "<script>alert('You username or password incorrect!')</script>";
		echo "<script>setTimeout(\"location.href = 'ThreeLogin.html';\",500);</script>";
	}
  }
/*$username=$_POST['username'];
$password=$_POST['password'];

$sql = "SELECT * FROM studentlogin WHERE stuName='$username' AND stuPassword='$password'";
$result = $conn->query($sql);

if (!$result = $result->fetch_assoc()) {
	//echo ("You username or password incorrect!");
	echo "<script>alert('You username or password incorrect!')</script>";
	echo "<script>setTimeout(\"location.href = 'ThreeLogin.html';\",500);</script>";
	
}
else {
	
	header('location:admin.html');

}*/


?>