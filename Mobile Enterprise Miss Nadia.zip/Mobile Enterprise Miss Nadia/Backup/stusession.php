<?php
	//Start session
	session_start();

	//Check whether the session variable SESS_STUDENT_ID is present or not
	if(!isset($_SESSION['Stu_ID']) || (trim($_SESSION['Stu_ID']) == '')) {
		header("location:StudentUploadPage.php");
		exit();
	}
?>
